import javax.swing.table.AbstractTableModel;
import java.util.ArrayList;

public class ProductTableModel<T extends Product> extends AbstractTableModel {
    private final String[] columnNames = {"Product ID", "Name", "Category", "Price (£)", "Info"};
    private final ArrayList<T> products;

    public ProductTableModel(ArrayList<T> products) {
        this.products = products;
    }

    @Override
    public int getColumnCount() {
        return this.columnNames.length;
    }

    @Override
    public int getRowCount() {
        return this.products.size();
    }

    @Override
    public Object getValueAt(int row, int col) {
        Object temp = null;
        if (col == 0) {
            temp = products.get(row).getProductId();
        }
        else if (col == 1) {
            temp = products.get(row).getProductName();
        }
        else if (col == 2) {
            if (products.get(row) instanceof Electronics) {
                temp = "Electronics";
            }
            else if (products.get(row) instanceof Clothing) {
                temp = "Clothing";
            }
        }
        else if (col == 3) {
            temp = products.get(row).getPrice();
        }
        else if (col == 4) {
            if (products.get(row) instanceof Electronics) {
                temp = ((Electronics)products.get(row)).getBrand() + ", " + ((Electronics)products.get(row)).getWarrantyPeriod();
            }
            else if (products.get(row) instanceof Clothing) {
                temp = ((Clothing)products.get(row)).getSize() + ", " + ((Clothing)products.get(row)).getColour();
            }
        }
        return temp;
    }

    @Override
    public String getColumnName(int col) {
        return columnNames[col];
    }
}