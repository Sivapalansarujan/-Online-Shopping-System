import java.io.Serializable;

public class User implements Serializable{
    // private instance variables
    private String username;
    private String password;

    // Constructor taking username and password as arguments
    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }

    // Getter method for username
    public String getUsername() {
        return this.username;
    }

    // Setter method for username
    public void setUsername(String username) {
        this.username = username;
    }

    // Getter method for password
    public String getPassword() {
        return this.password;
    }

    // Setter method for password
    public void setPassword(String password) {
        this.password = password;
    }
}