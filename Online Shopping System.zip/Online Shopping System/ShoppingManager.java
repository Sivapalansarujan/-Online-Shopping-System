public interface ShoppingManager {
// signature

}