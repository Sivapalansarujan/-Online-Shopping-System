//The Electronic class serves as a subclass for representing products.
public class Electronics extends Product {

    private String brand;
    private String warrantyPeriod;

    // constructor to initialise the electronic product with the relevant values.
    public Electronics(String productId, String productName, int numberOfAvailableItems, double price, String brand, String warrantyPeriod) {
        // call the constructor of the super class.
        super(productId, productName, numberOfAvailableItems, price);
        this.brand = brand;
        this.warrantyPeriod = warrantyPeriod;
    }

    // Getter method to retrieve the brand
    public String getBrand() {
        return this.brand;
    }

    // Setter method to set or update the brand
    public void setBrand(String brand) {
        this.brand = brand;
    }

    // Getter method to retrieve the brand
    public String getWarrantyPeriod() {
        return this.warrantyPeriod;
    }

    // Setter method for to set or update warrantyPeriod
    public void setWarrantyPeriod(String warrantyPeriod) {
        this.warrantyPeriod = warrantyPeriod;
    }
}