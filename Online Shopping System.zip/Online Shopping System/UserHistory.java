import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;

public class UserHistory {

    private final ArrayList<String> productsNameHistory;

    public UserHistory() {
        productsNameHistory = new ArrayList<String>();
    }

    public void addProducts(Product product) {
        this.productsNameHistory.add(product.getProductName());
    }

    public ArrayList<String> getProductsNameHistory() {
        return this.productsNameHistory;
    }
}