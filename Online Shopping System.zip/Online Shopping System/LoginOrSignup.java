import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.HashMap;


public class LoginOrSignup extends JFrame {
    private static JDialog dialog;
    private static JDialog questionDialog;
    private static JDialog loginDialog;
    private static JDialog signupDialog;
    private static JTextField textField;
    private static JTextField signupTextField;
    private static JPasswordField passwordField;
    private static JPasswordField signupPasswordField;
    private static JLabel emptyNote;
    private static JLabel emptyNote2;
    protected static ShoppingCart shoppingCart;
    protected static String mode;
    protected static String currentUsername;
    protected static HashMap<String, ArrayList<Product>> allUserHistory;
    private ArrayList<String> userProductsNameHistory;

    public static void accountClarification() {
            // Code for displaying a dialog to clarify if the user has an account
        questionDialog = new JDialog();
        questionDialog.setTitle(" Account Clarification ");
        questionDialog.setSize(450, 150);

        JLabel question = new JLabel(" Do you have a westminster shopping account ? ");
        JPanel p1 = new JPanel(new FlowLayout(FlowLayout.CENTER));
        p1.add(question);
        questionDialog.getContentPane().add(p1, BorderLayout.NORTH);

        JPanel choice = new JPanel(new GridLayout(1, 2, 40, 0));
        JButton choice1 = new JButton(" YES ");
        choice1.addActionListener(new ChoiceOneHandler());
        JButton choice2 = new JButton(" NO ");
        choice2.addActionListener(new ChoiceTwoHandler());
        choice.add(choice1);
        choice.add(choice2);
        questionDialog.getContentPane().add(choice, BorderLayout.SOUTH);

        questionDialog.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        questionDialog.setLocationRelativeTo(null);
        questionDialog.setResizable(false);
        questionDialog.setVisible(true);
    }
    // Method to handle the login functionality
    public static void LoginFunction()
    {

        loginDialog = new JDialog(questionDialog, " Westminster Shopping Account Login ", true);
        loginDialog.setSize(400, 170);
        loginDialog.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        loginDialog.setLayout(new BorderLayout());

        JPanel p1 = get_p1();
        JButton loginButton = new JButton("Login");
        loginButton.setMargin(new Insets(5, 5, 5, 5));
        loginButton.setToolTipText(" Click to login ");
        loginButton.addActionListener(new UserLoginHandler());

        JPanel p5 = new JPanel(new FlowLayout(FlowLayout.CENTER));
        p5.add(loginButton);

        loginDialog.getContentPane().add(p1, BorderLayout.CENTER);
        loginDialog.getContentPane().add(p5, BorderLayout.SOUTH);

        loginDialog.setLocationRelativeTo(null);
        loginDialog.setVisible(true);
    }
    // Method to create the main panel for login
    private static JPanel get_p1()
    {
        JPanel p1 = new JPanel(new GridLayout(3, 1, 10, 5));

        JLabel username = new JLabel(" Username: ");

        textField = new JTextField();
        textField.setColumns(15);
        textField.setToolTipText(" Enter your username ");

        JLabel password = new JLabel(" Password: ");

        passwordField = new JPasswordField();
        passwordField.setColumns(15);
        passwordField.setToolTipText(" Enter your password ");

        JPanel p2 = new JPanel(new FlowLayout(FlowLayout.CENTER));
        p2.add(username);
        p2.add(textField);

        JPanel p3 = new JPanel(new FlowLayout(FlowLayout.CENTER));
        p3.add(password);
        p3.add(passwordField);

        JPanel p4 = new JPanel(new FlowLayout(FlowLayout.CENTER));
        emptyNote = new JLabel("");
        p4.add(emptyNote);

        p1.add(p2);
        p1.add(p3);
        p1.add(p4);
        return p1;
    }
    // Method to handle user login
    public static void userLoginHandling()
    {
        if ((textField.getText().isEmpty() && passwordField.getPassword().length == 0) || (textField.getText().isEmpty() || passwordField.getPassword().length == 0)) {
            if (textField.getText().isEmpty() && passwordField.getPassword().length == 0) {
                emptyNote.setText(" Both Fields are Empty. ");
            }
            else if (textField.getText().isEmpty()) {
                emptyNote.setText(" Username is Empty. ");
            }
            else if (passwordField.getPassword().length == 0) {
                emptyNote.setText(" Password is Empty. ");
            }
            emptyNote.setForeground(Color.RED);
        }
        else {
            if (AccountManager.getUserByUsername(textField.getText()) != null) {
                User currentUser = AccountManager.getUserByUsername(textField.getText());
                String enteredPassword = new String(passwordField.getPassword());
                if (enteredPassword.equals(currentUser.getPassword())) {
                    loginDialog.dispose();
                    System.out.println(" ok to proceed ");
                    currentUsername = currentUser.getUsername();
                    boolean isFound = false;
                    for (String key : GraphicalUserInterface.retrieveUserHistory().keySet()) {
                        if (key.equals(currentUsername)) {
                            isFound = true;
                        }
                    }
                    if (!isFound) {
                        System.out.println(" Error, LoginOrSignup ");
                        mode = "AccountHolder";
                        LoginOrSignup.allUserHistory = GraphicalUserInterface.retrieveUserHistory();
                        LoginOrSignup.allUserHistory.put(currentUsername, new ArrayList<Product>());
                    }
                    else {
                        mode = "AccountHolder";
                        LoginOrSignup.allUserHistory = GraphicalUserInterface.retrieveUserHistory();
                    }
                    SwingUtilities.invokeLater(GraphicalUserInterface::new);
                    shoppingCart = new ShoppingCart();
                }
                else {
                    emptyNote.setForeground(Color.RED);
                    emptyNote.setText(" Password incorrect ");
                }
            }
            else {
                System.out.println(" Not Found ");
            }
        }
    }
// Method to handle the choice of creating a new account
    public static void signupChoice() {
        signupDialog = new JDialog(questionDialog, " Account Creation Choice ", true);
        signupDialog.setSize(450, 150);
        signupDialog.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JLabel createChoice = new JLabel(" Create New Account ? ");
        JPanel p1 = new JPanel(new FlowLayout(FlowLayout.CENTER));
        p1.add(createChoice);
        signupDialog.getContentPane().add(p1, BorderLayout.NORTH);

        JPanel choice = new JPanel(new GridLayout(1, 2, 40, 0));
        JButton choice1 = new JButton(" YES ");
        choice1.addActionListener(new SignupYesHandler());
        JButton choice2 = new JButton(" NO ");
        choice2.addActionListener(new SignupNoHandler());
        choice.add(choice1);
        choice.add(choice2);
        signupDialog.getContentPane().add(choice, BorderLayout.SOUTH);

        signupDialog.setResizable(false);
        signupDialog.setLocationRelativeTo(null);
        signupDialog.setVisible(true);
    }
    // Method to handle account creation
    public static void accountCreation()
    {
        JDialog createDialog = new JDialog(signupDialog, " Account Creation ", true);
        createDialog.setSize(400, 170);
        createDialog.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        createDialog.setLayout(new BorderLayout());

        JPanel p1 = new JPanel(new GridLayout(3, 1, 10, 5));

        JLabel username = new JLabel(" Set your username: ");
        signupTextField = new JTextField();
        signupTextField.setColumns(15);
        signupTextField.setToolTipText(" Set valid username ");

        JLabel password = new JLabel(" Set your password: ");

        signupPasswordField = new JPasswordField();
        signupPasswordField.setColumns(15);
        signupPasswordField.setToolTipText(" Set valid password ");

        JButton createAccountButton = new JButton(" Create Account ");
        createAccountButton.setMargin(new Insets(5, 5, 5, 5));
        createAccountButton.setToolTipText(" Click to create new account ");
        createAccountButton.addActionListener(new createAccountHandler());

        JPanel p5 = new JPanel(new FlowLayout(FlowLayout.CENTER));
        p5.add(createAccountButton);

        JPanel p2 = new JPanel(new FlowLayout(FlowLayout.CENTER));
        p2.add(username);
        p2.add(signupTextField);

        JPanel p3 = new JPanel(new FlowLayout(FlowLayout.CENTER));
        p3.add(password);
        p3.add(signupPasswordField);

        JPanel p4 = new JPanel(new FlowLayout(FlowLayout.CENTER));
        emptyNote2 = new JLabel("");
        p4.add(emptyNote2);

        p1.add(p2);
        p1.add(p3);
        p1.add(p4);

        createDialog.getContentPane().add(p1, BorderLayout.CENTER);
        createDialog.getContentPane().add(p5, BorderLayout.SOUTH);

        createDialog.setResizable(false);
        createDialog.setLocationRelativeTo(null);
        createDialog.setVisible(true);
    }
    // Method to handle the creation of a new account
    public static void createAccountHandling() {
        if ((signupTextField.getText().isEmpty() && signupPasswordField.getPassword().length == 0) || (signupTextField.getText().isEmpty() || signupPasswordField.getPassword().length == 0)) {
            if (signupTextField.getText().isEmpty() && signupPasswordField.getPassword().length == 0) {
                emptyNote2.setText(" Both Fields are Empty. ");
            }
            else if (signupTextField.getText().isEmpty()) {
                emptyNote2.setText(" Username is Empty. ");
            }
            else if (signupPasswordField.getPassword().length == 0) {
                emptyNote2.setText(" Password is Empty. ");
            }
            emptyNote2.setForeground(Color.RED);
        }

        else {
            boolean sameUsername = false;

            String newUsername = signupTextField.getText();
            char[] chars = signupPasswordField.getPassword();
            String newPassword = new String(chars);

            AccountManager.createUserAccount(newUsername, newPassword);

            signupDialog.dispose();
            currentUsername = newUsername;
            mode = " AccountHolder ";
            allUserHistory = GraphicalUserInterface.retrieveUserHistory();
            for (String key : allUserHistory.keySet()) {
                if (key.equals(currentUsername)) {
                    sameUsername = true;
                }
            }
            if (!sameUsername) {
                allUserHistory.put(currentUsername, new ArrayList<Product>());
                SwingUtilities.invokeLater(GraphicalUserInterface::new);
                shoppingCart = new ShoppingCart();
            }
            else {
                System.out.println(" same username found. ");
            }
        }
    }
    // Method to inform the user about no account discounts
    public static void noAccountUserNote()
    {
        dialog = new JDialog(signupDialog, " No Discounts ", true);
        dialog.setSize(400, 150);
        dialog.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        dialog.setLayout(new BorderLayout());

        JPanel p1 = new JPanel(new GridLayout(2, 1, 10, 2));
        JPanel p2 = new JPanel(new FlowLayout(FlowLayout.CENTER));
        p2.add(new JLabel("<html>Note: Exclusive discounts are provided to account holders.<br>&nbsp; Non-account holders will not receive any discounts.</html>"));
        p1.add(p2);

        JPanel p3 = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JButton proceedButton = new JButton(" Proceed ");
        proceedButton.setToolTipText(" Click to proceed ");
        proceedButton.setMargin(new Insets(5, 5, 5, 5));
        proceedButton.addActionListener(new ProceedHandler());
        p3.add(proceedButton);

        p1.add(p2);

        dialog.getContentPane().add(p1, BorderLayout.CENTER);
        dialog.getContentPane().add(p3, BorderLayout.SOUTH);

        dialog.setResizable(false);
        dialog.setLocationRelativeTo(null);
        dialog.setVisible(true);
    }

    private static class ProceedHandler implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent event) {
            dialog.dispose();
            mode = "NonAccountHolder";
            SwingUtilities.invokeLater(GraphicalUserInterface::new);
            shoppingCart = new ShoppingCart();
        }
    }

    private static class ChoiceOneHandler implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent event) {
            questionDialog.dispose();
            LoginFunction();
        }
    }

    private static class ChoiceTwoHandler implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent event) {
            questionDialog.dispose();
            signupChoice();
        }
    }

    private static class UserLoginHandler implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent event) {
            userLoginHandling();
        }
    }

    public static class SignupYesHandler implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent event) {
            signupDialog.dispose();
            accountCreation();
        }
    }

    public static class SignupNoHandler implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent event) {
            questionDialog.dispose();
            noAccountUserNote();
        }
    }

    public static class createAccountHandler implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent event) {
            createAccountHandling();
        }
    }
}