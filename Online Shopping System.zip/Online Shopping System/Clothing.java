//The Clothing class serves as a subclass for representing products.
public class Clothing extends Product {

    private String size;
    private String colour;

    // constructor to initialise the electronic product with the relevant values.
    public Clothing(String productId, String productName, int numberOfAvailableItems, double price, String size, String colour) {
        // call the constructor of the super class.
        super(productId, productName, numberOfAvailableItems, price);
        this.size = size;
        this.colour = colour;
    }

    // Getter method to retrieve the cloth size
    public String getSize() {
        return this.size;
    }

    // Setter method to set or update the cloth size
    public void setSize(String size) {
        this.size = size;
    }

    // Getter method to retrieve the cloth colour
    public String getColour() {
        return this.colour;
    }

    // Setter method to set or update the cloth colour
    public void setColour(String colour) {
        this.colour = colour;
    }
}