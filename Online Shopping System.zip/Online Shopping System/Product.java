import java.io.Serializable;

   // The Product class serves as an abstract base class for representing various products.
public abstract class Product implements Serializable {
    private String productId;
    private String productName;
    private int numberOfAvailableItems;
    private double price;

   // constructor to initialise the product with the relevant values.
    public Product(String productId, String productName, int numberOfAvailableItems, double price) {
        this.productId = productId;
        this.productName = productName;
        this.numberOfAvailableItems = numberOfAvailableItems;
        this.price = price;
    }

    // Getter method to retrieve the product's ID.
    public String getProductId() {
        return this.productId;
    }

    // Setter method to set or update the product's ID.
    public void setProductId(String productId) {
        this.productId = productId;
    }

    // Getter method to retrieve the product's name.
    public String getProductName() {
        return this.productName;
    }

    // Setter method to set or update the product's name.
    public void setProductName(String productName) {
        this.productName = productName;
    }

    // Getter method to retrieve the number of available items.
    public int getNumberOfAvailableItems() {
        return this.numberOfAvailableItems;
    }

    // Setter method to set or update the number of available items.
    public void setNumberOfAvailableItems(int numberOfAvailableItems) {
        this.numberOfAvailableItems = numberOfAvailableItems;
    }

    // Getter method for price
    public double getPrice() {
        return this.price;
    }

    // Setter method for price
    public void setPrice(double price) {
        this.price = price;
    }
}