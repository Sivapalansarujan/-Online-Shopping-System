import java.util.Scanner;
import java.util.ArrayList;
import java.util.Collections;
import javax.swing.SwingUtilities;
import java.io.*;

public class WestminsterShoppingManager implements ShoppingManager {
    // Constants and data structures for managing products
    private static final String fileName="Products_Details.txt";
    protected static final ArrayList<Product> productsList=new ArrayList<Product>();
    private static final ArrayList<String> productIds=new ArrayList<String>();
    private static final int maximumProducts=50;
    private static int productsCount=GraphicalUserInterface.readAllProducts().size();
    private static final Scanner scanner=new Scanner(System.in);

    // Main method to start program
    public static void main(String[] args) {
        menuFunction();
    }

    // Main menu function to access user choices
    public static void menuFunction() {
        while (true) {
            // Display menu options
            displayMenu();

            // Get user input for menu choice
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline character

            // Perform action based on user choice
            handleMenuChoice(choice);
        }
    }
    // Function to display the menu options
    public static void displayMenu() {
        System.out.println( "________________________________" );
        System.out.println( "********************************" );
        System.out.println( "****** Menu Options ******" );
        System.out.println( "********************************" );
        System.out.println( " 1 - Add new product " );
        System.out.println( " 2 - Delete product " );
        System.out.println( " 3 - Print products list " );
        System.out.println( " 4 - Save products details in file " );
        System.out.println( " 5 - Open GUI " );
        System.out.println( " 6 - Exit program " );
        System.out.println( "********************************" );
        System.out.println();
        System.out.println( " Enter option: " );
    }
         // Function to handle user choices from the menu
    public static void handleMenuChoice(int choice) {

        // Switch statement to perform actions based on user choice
        switch (choice) {
            case 1:
                addNewProduct();
                break;
            case 2:
                deleteProduct();
                break;
            case 3:
                printProductsList();
                break;
            case 4:
                saveInAFile();
                break;
            case 5:
                openGui();
                break;
            case 6:
                System.out.println( "Program exited." );
                // exit the program
                System.exit(0);
            default:
                System.out.println( " Wrong choice! select a valid option. " );
        }
    }

    // Function to add a new product
        public static void addNewProduct() {
        if (productsCount <= maximumProducts) {
            while (true) {
                System.out.print("  Which category: \n    (Note: Type 'e' if it is electronics, 'c' if it is clothing.) \n\t");
                String categoryChoice = scanner.nextLine();

                if (categoryChoice.length() == 1 && (categoryChoice.charAt(0) == 'e' || categoryChoice.charAt(0) == 'c')) {
                    if (categoryChoice.equals("e")) {
                        String restartAddingChoice = null;
                        String electronicProductId;

                        System.out.println("   ** You have to fill the following details about that particular electronic product.");
                        while (true) {
                            System.out.print("    1. Enter the product ID: ");
                            electronicProductId = scanner.nextLine();

                            if (!productsList.isEmpty()) {
                                boolean isFound = false;
                                for (Product product: productsList) {
                                    if (electronicProductId.equals(product.getProductId())) {
                                        isFound = true;
                                        System.out.println("  This product id already in the product id list. \n\t\t  Note: You are not allowed to having different products with same product id.");
                                        System.out.println();
                                        System.out.print(" Would you like to restart the adding process (yes/no): ");
                                        restartAddingChoice = scanner.nextLine();

                                        if (restartAddingChoice.equals("yes")) {
                                            System.out.println();
                                            break;
                                        }
                                        else if (restartAddingChoice.equals("no")) {
                                            isFound = false;
                                            break;
                                        }
                                        else {
                                            System.out.println("      Invalid choice! Adding process terminated. ");
                                            restartAddingChoice = "invalid";
                                            isFound = false;
                                            break;
                                        }
                                    }
                                }
                                if (!isFound) {
                                    break;
                                }
                            }
                            else {
                                break;
                            }
                        }
                        if (restartAddingChoice != null && (restartAddingChoice.equals("no") || restartAddingChoice.equals("invalid"))) {
                            break;
                        }
                        System.out.print("    2. Enter a product name: ");
                        String electronicProductName = scanner.nextLine();
                        System.out.print("    3. How many items are you going to add: ");
                        int addItemsCount = scanner.nextInt();
                        System.out.print("    4. Price of the product (in pounds): £");
                        double productPrice = scanner.nextDouble();
                        scanner.nextLine();
                        System.out.print("    5. Product brand: ");
                        String productBrand = scanner.nextLine();
                        System.out.print("    6. Warranty period: ");
                        String warrantyPeriod = scanner.nextLine();

                        Electronics electronicProduct = new Electronics(electronicProductId, electronicProductName, addItemsCount, productPrice, productBrand, warrantyPeriod);
                        productsList.add(electronicProduct);

                        System.out.println();
                        System.out.println("        ✓ Product having product Id \"" + electronicProductId + "\" added to the system successfully.");
                        productsCount++;
                    }
                    else if (categoryChoice.equals("c")) {
                        String restartAddingChoice = null;
                        String clothingProductId;

                        System.out.println("   ** You have to fill the following details about that particular clothing product.");
                        while (true) {
                            System.out.print("    1. Enter the product ID: ");
                            clothingProductId = scanner.nextLine();

                            if (!productsList.isEmpty()) {
                                boolean isFound = false;
                                for (Product product: productsList) {
                                    if (clothingProductId.equals(product.getProductId())) {
                                        isFound = true;
                                        System.out.println("     This product id already in the product id list. \n\t\t  Note: You are not allowed to having different products with same product id.");
                                        System.out.println();
                                        System.out.print("     Would you like to restart the adding process (yes/no): ");
                                        restartAddingChoice = scanner.nextLine();

                                        if (restartAddingChoice.equals("yes")) {
                                            System.out.println();
                                            break;
                                        }
                                        else if (restartAddingChoice.equals("no")) {
                                            isFound = false;
                                            break;
                                        }
                                        else {
                                            System.out.println("     Invalid choice! Process terminate. ");
                                            restartAddingChoice = "invalid";
                                            isFound = false;
                                            break;
                                        }
                                    }
                                }
                                if (!isFound) {
                                    break;
                                }
                            }
                            else {
                                break;
                            }
                        }
                        if (restartAddingChoice != null && (restartAddingChoice.equals("no") || restartAddingChoice.equals("invalid"))) {
                            break;
                        }

                        System.out.print("    2. Enter the product name: ");
                        String clothingProductName = scanner.nextLine();
                        System.out.print("    3. How many items are you going to add: ");
                        int addItemsCount = scanner.nextInt();
                        System.out.print("    4. Price of the product(in pounds): £");
                        double productPrice = scanner.nextDouble();
                        scanner.nextLine();
                        System.out.print("    5. Size of the clothing: ");
                        String productSize = scanner.nextLine();
                        System.out.print("    6. Colour of the clothing: ");
                        String productColour = scanner.nextLine();

                        Clothing clothingProduct = new Clothing(clothingProductId, clothingProductName, addItemsCount, productPrice, productSize, productColour);
                        productsList.add(clothingProduct);

                        System.out.println();
                        System.out.println("     Product having product Id \"" + clothingProductId + "\" have been added to the system successfully.");
                        productsCount++;
                    }



                    String anotherAdding;
                    while (true) {
                        System.out.println();
                        System.out.println();
                        System.out.print("     Do you want to add another product(yes/no): ");
                        anotherAdding = scanner.nextLine();

                        if (anotherAdding.equals("no")) {
                            break;
                        }
                        else if (anotherAdding.equals("yes")) {
                            System.out.println();
                            break;
                        }
                        else {
                            System.out.println(" Try again. ");
                            System.out.println( );
                        }
                    }
                    if (anotherAdding.equals("no")) {
                        break;
                    }
                }
                else {
                    String choiceAtInvalid;
                    System.out.println("   ! Invalid input. ");

                    while (true) {
                        System.out.print("  Do you want to continue the adding process(yes/no): \n\t");
                        choiceAtInvalid = scanner.nextLine();

                        if (choiceAtInvalid.equals("yes")) {
                            System.out.println();
                            break;
                        }
                        else if (choiceAtInvalid.equals("no")) {
                            break;
                        }
                        else {
                            System.out.println(" Try again. ");
                        }
                    }
                    if (choiceAtInvalid.equals("no")) {
                        break;
                    }
                }
            }
        }
        else {
            System.out.println(" unable to add a new product. Because system reached it's maximum storage limit (maximum 50). ");
        }
    }

    // Function to delete a product
    public static void deleteProduct() {
        while (true) {
            if (GraphicalUserInterface.readAllProducts().isEmpty()) {
                System.out.println("    No products in the system. You cannot further progress to the deleting item .");
                System.out.println();
                break;
            }
            System.out.print("  Enter the ID of the product you want to delete : ");
            String deleteId = scanner.nextLine();

            boolean idMatching = false;
            Product productForDelete = null;
            ArrayList<Product> list = GraphicalUserInterface.readAllProducts();
            if (!list.isEmpty()) {
                for (Product product : list) {
                    if (product.getProductId().equals(deleteId)) {
                        idMatching = true;
                        productForDelete = product;
                        break;
                    }
                }

                if (idMatching) {
                    System.out.print("   Are you sure about the delete progress (yes/no): \n\t");
                    String lastChance = scanner.nextLine();

                    String addPhrase = null;
                    if (lastChance.equals("yes")) {

                        if (productForDelete instanceof Electronics) {
                            addPhrase = "Electronics";
                        }
                        else if (productForDelete instanceof Clothing) {
                            addPhrase = "Clothing";
                        }

                        System.out.println("   ✻ Details of this product at the time of delete. ");
                        System.out.println("\t → Product id: " + productForDelete.getProductId());
                        System.out.println("\t → Product name: " + productForDelete.getProductName());
                        System.out.println("\t → Number of available items: " + productForDelete.getNumberOfAvailableItems());
                        System.out.println("\t → Price: £"+ productForDelete.getPrice());

                        if (productForDelete instanceof Electronics) {
                            System.out.println("\t → Brand: " + ((Electronics) productForDelete).getBrand());
                            System.out.println("\t → Warranty period: " + ((Electronics) productForDelete).getWarrantyPeriod());
                        }
                        else if (productForDelete instanceof Clothing) {
                            System.out.println("\t → Size: " + ((Clothing) productForDelete).getSize());
                            System.out.println("\t → Colour: " + ((Clothing) productForDelete).getColour());
                        }

                        list.remove(productForDelete);

                        try (ObjectOutputStream output = new ObjectOutputStream(new FileOutputStream("details_byte.txt"))) {
                            output.writeObject(list);
                        } catch (IOException e) {

                            System.out.println(" Error at the time of save after delete product. ");
                        }

                        try (FileWriter writer = new FileWriter(fileName)) {
                            for (Product product : GraphicalUserInterface.readAllProducts()) {
                                writer.write("✽ Product name: " + product.getProductName() + "\n");
                                writer.write("\t→ Product id: " + product.getProductId() + "\n");
                                writer.write("\t→ Number of available items: " + product.getNumberOfAvailableItems() + "\n");
                                writer.write("\t→ Price: £"+ product.getPrice() + "\n");
                                if (product instanceof Electronics) {
                                    writer.write("\t→ Brand: " + ((Electronics) product).getBrand() + "\n");
                                    writer.write("\t→ Warranty period: " + ((Electronics) product).getWarrantyPeriod() + "\n\n");
                                }
                                else if (product instanceof Clothing) {
                                    writer.write("\t→ Size: " + ((Clothing) product).getSize() + "\n");
                                    writer.write("\t→ Colour: " + ((Clothing) product).getColour() + "\n\n");
                                }
                            }
                        } catch (IOException e) {
                            System.out.println("error while writing to the file after deletion");
                        }

                        productsCount--;
                        System.out.println();
                        System.out.println("   ✓ Product which belongs to \"" + addPhrase + "\" category and having product id \"" + productForDelete.getProductId() + "\" successfully deleted from the system.");
                        System.out.println();
                        System.out.println("    Total number of remaining products in the system: " + productsCount);
                        System.out.println();

                        System.out.print("   Do you want to progress to another delete process (yes or no): \n\t");
                        String anotherDelete = scanner.nextLine();

                        if (anotherDelete.equals("no")) {
                            break;
                        }
                    }
                    else if (lastChance.equals("no")) {
                        System.out.println("   Delete item process terminated.");
                        break;
                    }
                    else {
                        System.out.println("   Not an expected response. Delete item process terminated. ");
                        break;
                    }
                }
                else {
                    System.out.println("   There is no such a product having the entered product id. ");
                    System.out.println("   Do you want to restart the delete item process (yes/no): ");
                    String afterInvalid = scanner.nextLine();

                    if (afterInvalid.equals("no")) {
                        break;
                    }
                }
            }
            else {
                System.out.println("    System has no products.");
            }
        }
    }

    // Function to print the list of products
    public static void printProductsList() {
        productIds.clear();
        ArrayList<Product> productsDetails = GraphicalUserInterface.readAllProducts();

        if (!productsDetails.isEmpty()) {
            for (Product product : productsDetails) {
                productIds.add(product.getProductId());
            }

            Collections.sort(productIds);

            System.out.println("     Below is the list of products in the system with relevant details. ");
            System.out.println("     (List ordered alphabetically according to product id)");
            System.out.println();

            int i = 1;
            for (String productId : productIds) {
                for (Product product : productsDetails) {
                    if (productId.equals(product.getProductId())) {
                        System.out.println("\t" + i + ". Product name: " + product.getProductName());
                        System.out.println("\t   Product category: " + ((product instanceof Electronics) ? "Electronics" : "Clothing"));
                        System.out.println("\t\t → Product id: " + product.getProductId());
                        System.out.println("\t\t → Number of available items: " + product.getNumberOfAvailableItems());
                        System.out.println("\t\t → Price: £"+ product.getPrice());
                        if (product instanceof Electronics) {
                            System.out.println("\t\t → Brand: " + ((Electronics) product).getBrand());
                            System.out.println("\t\t → Warranty period: " + ((Electronics) product).getWarrantyPeriod());
                        }
                        else if (product instanceof Clothing) {
                            System.out.println("\t\t → Size: " + ((Clothing) product).getSize());
                            System.out.println("\t\t → Colour: " + ((Clothing) product).getColour());
                        }
                        System.out.println();
                    }
                }
                i++;
            }
        }
        else {
            System.out.println("\t  No products in the system.");
        }
    }

    // Function to save product details in a file
    public static void saveInAFile() {
        boolean isStored = false;
        ArrayList<Product> addItemList = new ArrayList<Product>();

        ArrayList<Product> arrayList = GraphicalUserInterface.readAllProducts();

        if (arrayList.isEmpty()) {
            addItemList.addAll(productsList);
        }
        else {
            for (Product product : productsList) {
                boolean isFound = false;
                for (Product productPrevious : arrayList) {
                    if (product.getProductId().equals(productPrevious.getProductId())) {
                        isFound = true;
                        break;
                    }
                }
                if (!isFound) {
                    addItemList.add(product);
                }
            }
        }
        arrayList.addAll(addItemList);

        try (ObjectOutputStream output = new ObjectOutputStream(new FileOutputStream("details_byte.txt"))) {
            output.writeObject(arrayList);
            isStored = true;
        } catch (IOException e) {
            System.out.println("  error in saveInAFile() ");
        }

        if (isStored) {
            try (FileWriter writer = new FileWriter(fileName)) {
                for (Product product : GraphicalUserInterface.readAllProducts()) {
                    writer.write("✽ Product name: " + product.getProductName() + "\n");
                    writer.write("\t→ Product id: " + product.getProductId() + "\n");
                    writer.write("\t→ Number of available items: " + product.getNumberOfAvailableItems() + "\n");
                    writer.write("\t→ Price: £"+ product.getPrice() + "\n");
                    if (product instanceof Electronics) {
                        writer.write("\t→ Brand: " + ((Electronics) product).getBrand() + "\n");
                        writer.write("\t→ Warranty period: " + ((Electronics) product).getWarrantyPeriod() + "\n\n");
                    }
                    else if (product instanceof Clothing) {
                        writer.write("\t→ Size: " + ((Clothing) product).getSize() + "\n");
                        writer.write("\t→ Colour: " + ((Clothing) product).getColour() + "\n\n");
                    }
                }
            } catch (IOException e) {
                System.out.println("file write");
            }
        }
        System.out.println("\t  Successfully saved in the file.");
        productsList.clear();
    }

    // Function to open the Graphical User Interface
    public static void openGui() {
        // Create and display the Graphical User Interface on the Event Dispatch Thread
        SwingUtilities.invokeLater(LoginOrSignup::accountClarification);
    }
}