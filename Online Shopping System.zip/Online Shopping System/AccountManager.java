import java.io.*;
import java.util.ArrayList;

public class AccountManager {
    private static final String fileName = "UserCredentials.txt";

    public static void createUserAccount(String username, String password) {
        ArrayList<User> userList = readUserAccounts();
        userList.add(new User(username, password));
        saveUserAccounts(userList);
    }

    @SuppressWarnings("unchecked")
    private static ArrayList<User> readUserAccounts() {
        try (ObjectInputStream input = new ObjectInputStream(new FileInputStream(fileName))) {
            return (ArrayList<User>)input.readObject();
        } catch (IOException | ClassNotFoundException | ClassCastException e) {
            return new ArrayList<>();
        }
    }

    private static void saveUserAccounts(ArrayList<User> userList) {
        try (ObjectOutputStream output = new ObjectOutputStream(new FileOutputStream(fileName))) {
            output.writeObject(userList);
        } catch (IOException e) {
            System.out.println("Some error occurs in the saveUserAccounts method.");
        }
    }

    public static User getUserByUsername(String username) {
        ArrayList<User> userList = readUserAccounts();
        return userList.stream()
                .filter(user -> user.getUsername().equals(username))
                .findFirst()
                .orElse(null);
    }
}