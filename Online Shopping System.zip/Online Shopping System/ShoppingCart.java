import java.util.ArrayList;
import java.util.HashMap;

public class ShoppingCart {
    private final ArrayList<Product> cartProducts;
    private final HashMap<Product , Integer> quantityOfEach;
    private final HashMap<Product, Double> quantityPriceList;

    public ShoppingCart() {
        cartProducts = new ArrayList<Product>();
        quantityOfEach = new HashMap<Product, Integer>();
        quantityPriceList = new HashMap<Product, Double>();
    }

    public ArrayList<Product> getCartProducts() {
        return this.cartProducts;
    }

    public HashMap<Product, Integer> getQuantityOfEach() {
        return this.quantityOfEach;
    }

    public HashMap<Product, Double> getQuantityPriceList() {
        return this.quantityPriceList;
    }

    public void addToCart(Product product) {
        cartProducts.add(product);
    }

    public void addProductQuantity(Product product, int quantity) {
        quantityOfEach.put(product, quantity);
        updateQuantityPrice(product, quantity);
    }

    private void updateQuantityPrice(Product product, int quantity) {
        quantityPriceList.put(product, (product.getPrice() * quantity));
    }

    public void removeProduct(Product removeProduct) {
        for (Product product : cartProducts) {
            if (product.getProductId().equals(removeProduct.getProductId())) {
                cartProducts.remove(product);
                break;
            }
        }
        for (Product key : quantityOfEach.keySet()) {
            if (key.getProductId().equals(removeProduct.getProductId())) {
                quantityOfEach.remove(key);
            }
        }
        for (Product key : quantityPriceList.keySet()) {
            if (key.getProductId().equals(removeProduct.getProductId())) {
                quantityPriceList.remove(key);
            }
        }
    }

    public void removeProductQuantity(Product removeProduct) {
        quantityOfEach.remove(removeProduct);
    }

    public double calculateTotal() {
        double totalCost = 0;
        for (Product key : quantityOfEach.keySet()) {
            totalCost = totalCost + (key.getPrice() * 100 * quantityOfEach.get(key));
        }
        return totalCost / 100;
    }

    public boolean isAlreadyInTheCart(Product checkProduct) {
        for (Product product : cartProducts) {
            if (product.getProductId().equals(checkProduct.getProductId())) {
                return true;
            }
        }
        return false;
    }
}